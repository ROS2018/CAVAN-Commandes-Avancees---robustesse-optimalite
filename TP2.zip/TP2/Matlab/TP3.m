%% Definition de variable de YALMIP:
x = sdpvar(1,1)
y = sdpvar(1,1)
z = sdpvar(1,1)

%% definition de la fonction � minimiser:
f = 4 *x +7*y -3 * z;

%% Definition de contraintes:
C = [x >=7; y >= -4; z==10];

%% R�sulotion du problem:
diagn = solvesdp(C,f);

x = double(x)
y = double(y)
z= double(z)


