% Preparation:
%Q5.2
A = [1 0.5 0; 0 1 0; 1 0.5 1];
B = [1 1 1]';
C = [0 0 1] ;
F = [C*A ; C*A*A; C*A*A*A];
phi = [C*B 0 
       C*A*B C*B
       C*A^2*B C*A*B];
phi'*phi
phi'*F
Rs_ = [1 1 1]';
phi'*Rs_
DU = (phi'*phi)\phi'*(Rs_-F*[0.1 0.2 0.1]')
%%
H = [0.5 -0.5;-0.5 1]
f=[-2 -6]
A = [1 1; -1 2; 2 1]
b = [2 2 3]'
l=[0;0]
[x,fval]=quadprog(H,f,A,b,[],[],l,[])
%%
A = [1 0.5 ; 0 1];
B = [1 1]';
Q = sdpvar(2,2);
Y = sdpvar(1,2);
L1 = Q>=0;
L2=A'*Q+Q*A+(B*Y)'+B*Y <= 0;
L=L1+L2;
optimize(L);
Q = double(Q);
Y = double(Y);
K = Y*inv(Q);
eig(A+B*K)
% Q = sdpvar(length(A),length(A));
% Y = sdpvar(length(B),length(A));