function y = getbase(x)
%GETBASE (overloaded sdpvar/getbase on double)

y = x(:);