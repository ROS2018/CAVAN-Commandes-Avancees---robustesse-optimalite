function Q = randpsd(n)

Q = randn(n);Q = Q*Q';