function  p = removenonlinearity(p)
p.variabletype = 0*p.variabletype;
p.evalMap = [];