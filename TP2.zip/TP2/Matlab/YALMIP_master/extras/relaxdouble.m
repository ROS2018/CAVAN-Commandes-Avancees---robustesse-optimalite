function x = relaxdouble(x)
%RELAXDOUBLE (overloaded sdpvar/relaxdouble on double)

% Do nothing, just return input.