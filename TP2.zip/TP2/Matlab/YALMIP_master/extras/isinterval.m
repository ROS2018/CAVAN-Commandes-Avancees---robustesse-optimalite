function res = isinterval(Y)
%ISINTERVAL (overloaded)

res = isa(Y,'intval');
