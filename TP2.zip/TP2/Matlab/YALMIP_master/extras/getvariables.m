function vars = getvariables(X,var)
%GETVARIABLES (overloads sdpvar/getvariables on double)

vars = [];
