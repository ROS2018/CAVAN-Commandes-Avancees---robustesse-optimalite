function p = emptyNumericalModel;
p.F_struc = [];
p.K.f = 0;
p.K.l = 0;
p.K.q = 0;
p.K.s = 0;