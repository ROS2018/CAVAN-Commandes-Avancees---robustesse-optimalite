function t = definecreationtime

t = now;
