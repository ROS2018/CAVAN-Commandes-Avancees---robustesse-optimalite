function p = fraction(x)
p = x(1)./x(2);
