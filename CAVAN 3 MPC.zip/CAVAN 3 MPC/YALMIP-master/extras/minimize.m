function minimize(varargin)
disp('Functin not implemented')