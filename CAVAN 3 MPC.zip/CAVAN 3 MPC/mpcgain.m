function [ Phi_Phi,  Phi_F, Phi_R,Ae,Be,Ce ] = mpcgain( Ad,Bd,Cd,Nc,Np)
zero =diag(zeros(length(Ad)));
Ae = [Ad zero'
      Cd*Ad 1];
Be = [Bd ; Cd*Bd];
Ce = [zero 1];

h(1,:) = Ce;
F(1,:)=Ce*Ae;
for kk=2:Np
     h(kk,:)=h(kk-1,:)*Ae;
     F(kk,:)=F(kk-1,:)*Ae;
end

v=h*Be;
Phi = zeros(Np,Nc);
Phi(:,1)=v;

for i=2:Nc
    Phi(:,i)=[zeros(i-1,1) ; v(1:Np-i+1,1)]; % Toeplitz matrix
end

BarRs = ones(Np,1);
Phi_Phi=Phi'*Phi;
Phi_F=Phi'*F;
Phi_R=Phi'*BarRs;

end

